import React from 'react'

const Activity = () => {
  return (
    <div className='mt-4 p-5'>
      <p className='text-sm'>If a devloper askes for more information reagarding an eroor; please find the error on the list below, tap on it and copy everything in the gray text area.</p>
      <button className='p-2 px-4 bg-blue-400 rounded-md mt-4 text-sm text-white'>Download all</button>
    </div>
  )
}

export default Activity